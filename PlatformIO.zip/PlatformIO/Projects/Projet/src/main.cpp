#include <Arduino.h>

const int ledPin = 5; // GPIO 5 correspond au D5 sur la carte ESP32

void setup() {
  Serial.begin(9600); // Démarre la communication série à 9600 bauds
  pinMode(ledPin, OUTPUT); // Définir le GPIO comme sortie
}

void loop() {
  digitalWrite(ledPin, HIGH); // Allumer la LED (mettre le GPIO à HIGH)
  Serial.println("LED allumée"); // Afficher un message de débogage
  delay(1000); // Attendre 1 seconde
  
  digitalWrite(ledPin, LOW); // Éteindre la LED (mettre le GPIO à LOW)
  Serial.println("LED éteinte"); // Afficher un message de débogage
  delay(1000); // Attendre 1 seconde
}